#ifndef DELAY_H
#define	DELAY_H

void atraso_ms(unsigned int t);
void atraso_s(unsigned int t);

#endif	