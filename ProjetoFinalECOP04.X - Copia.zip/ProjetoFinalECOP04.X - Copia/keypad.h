#ifndef TECLADO_H
#define	TECLADO_H

    #define TL1 0x01
    #define TL2 0x02
    #define TL3 0x04

    unsigned char teclado(unsigned int timeout);

#endif	